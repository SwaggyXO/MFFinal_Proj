package proj.ncu.Ecomm_App.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

import proj.ncu.Ecomm_App.DAO.ProductDAOImpl;
import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.ProductPOJO;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
@MultipartConfig

public class ProductController {

	@Autowired
	ProductDAOImpl productDAOImpl;
	
	@ModelAttribute("productPOJO")
	ProductPOJO getSellerPOJO()
	{
		return new ProductPOJO();
	}
	
	@RequestMapping(value="/sellerView")
	public String sellerView() 
	{
		return "sellerView";
	}
	
	@RequestMapping(value= "/addProduct",method = RequestMethod.POST)
	public String addProdut( HttpServletRequest request,@Valid @ModelAttribute("productPOJO") ProductPOJO product,BindingResult br,Model model,@RequestParam("imagea") MultipartFile ml) throws IOException, ServletException 
	{
		if(br.hasErrors()) 
		{
			return "sellerView";
		}
		String filePath = "D:/jee-2021-062/apache-tomcat-9.0.54/webapps/ROOT/prod/"+ml.getOriginalFilename();
		String filePath2 = "/prod/"+ml.getOriginalFilename();
		System.out.println(filePath);
		ml.transferTo(new File(filePath));
		System.out.println(filePath);
		
		product.setImage(filePath2);
		
		product.setId(productDAOImpl.getSize()+1);
		
		productDAOImpl.addProduct(product);
		List<ProductPOJO> lis=productDAOImpl.getAllProducts();
		model.addAttribute("products",lis);
		return ("tempaaaa");
	}
	
	@RequestMapping("/updateForm")
	public String showUpdateForm(@RequestParam("id")int productId, @ModelAttribute("productPOJO") ProductPOJO product, Model model) 
	{
		System.out.println("Getting the product data for id: "+productId);
		product = productDAOImpl.getProduct(productId);
		/* send the student object to view */
		 model.addAttribute(product); 
		return "productUpdateForm";
	}

	@RequestMapping("/processUpdate")
	public String processUpdateForm(Model model,@ModelAttribute("productPOJO") ProductPOJO product) 
	{
		if(productDAOImpl.updateProduct(product) == 1) 
		{
			System.out.println("Record updated successfully!!");
		}
		else 
		{
			System.out.println("Error!!!");
		}
		List<ProductPOJO> lis=productDAOImpl.getAllProducts();
		model.addAttribute("products",lis);
		return "tempaaaa";
	}

	@RequestMapping("/deleteProduct")
	public String deleteBook(Model model,@RequestParam("id")int id,  @ModelAttribute("productPOJO") ProductPOJO product) 
	{
		productDAOImpl.deleteProduct(id);
		List<ProductPOJO> lis=productDAOImpl.getAllProducts();
		model.addAttribute("products",lis);
		return "tempaaaa";
	}
	
	@RequestMapping("/showSingle")
	public String getPojoByid(@RequestParam("id")int id,Model model) 
	{
		ProductPOJO product= productDAOImpl.getProduct(id);
		model.addAttribute("prod",product);
		return "productDetail";
	}
	
	@RequestMapping("/showByCateg")
	public String showByCateg(@RequestParam("categ")String categ,Model model) 
	{
		List<ProductPOJO> ls=productDAOImpl.getProductByCategory(categ);
		model.addAttribute("products",ls);
		System.out.println(ls);
		return "home";
	}
	
	
}
