package proj.ncu.Ecomm_App.DAO;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import proj.ncu.Ecomm_App.Entity.BuyerPOJO;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;
import proj.ncu.Ecomm_App.RowMapper.BuyerRowMapper;
import proj.ncu.Ecomm_App.RowMapper.SellerRowMapper;

@Repository
public class BuyerDAOImpl implements BuyerDAO
{
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<BuyerPOJO> getBuyer(String username) 
	{
		// TODO Auto-generated method stub
		String query = "select * from Buyer where username=?";
		Object[] args = { username };
		List<BuyerPOJO> ls = new ArrayList<BuyerPOJO>();
		ls = jdbcTemplate.query(query, args, new BuyerRowMapper());
		return ls;
	}

	@Override
	public void addBuyer(BuyerPOJO buyerpojo) 
	{
		// TODO Auto-generated method stub
		String add = "insert into buyer values(?,?,?)";
		Object[] args = {buyerpojo.getUsername(), buyerpojo.getPassword(), buyerpojo.getEmail() };
		int addS = jdbcTemplate.update(add, args);
		if (addS == 1)
		{
			System.out.println("Added Successfully!");
		}
		
		else
		{
			System.out.println("Unlucky :clown_face: ");
		}
	}

	@Override
	public boolean validateBuyer(String username, String password) {
		// TODO Auto-generated method stub
		String query = "select * from Buyer where username=?";
		Object[] args = { username };
		List<BuyerPOJO> ls = new ArrayList<BuyerPOJO>();
		ls = jdbcTemplate.query(query, args, new BuyerRowMapper());
		if(ls.size()==0)return false;
		ls.get(0).getPassword();
		if(ls.get(0).getPassword().equals(password)) 
		{
			return true;
		}
		return false;
	}

}

