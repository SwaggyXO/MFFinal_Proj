package proj.ncu.Ecomm_App.DAO;

import java.util.List;

import proj.ncu.Ecomm_App.Entity.SellerPOJO;

public interface sellerDAO {
	
	public List<SellerPOJO> getSeller(String username);
	
	public void addSeller(SellerPOJO sellerpojo);

}
