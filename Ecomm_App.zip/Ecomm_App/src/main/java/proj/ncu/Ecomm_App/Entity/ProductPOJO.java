package proj.ncu.Ecomm_App.Entity;

public class ProductPOJO {

}
