package proj.ncu.Ecomm_App.DAO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import proj.ncu.Ecomm_App.Entity.ProductPOJO;
import proj.ncu.Ecomm_App.RowMapper.ProductRowMapper;

@Repository
public class ProductDAOImpl implements ProductDAO {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public List<ProductPOJO> getAllProducts() {
		String query="select * from products";
		List<ProductPOJO> ls = new ArrayList<ProductPOJO>();
		ls = jdbcTemplate.query(query,  new ProductRowMapper());
		return ls;
	}
	
	public List<ProductPOJO> getProductByCategory(String category) {
		String query="select * from products where category=?";
		Object[] args= {category};
		List<ProductPOJO> ls = new ArrayList<ProductPOJO>();
		ls = jdbcTemplate.query(query, args, new ProductRowMapper());
		return ls;
	}
	
	public int getSize() 
	{
		String query="select * from products";
		List<ProductPOJO> ls = new ArrayList<ProductPOJO>();
		ls = jdbcTemplate.query(query, new ProductRowMapper());
		if(ls.size()==0)return 0;
		ProductPOJO pojo=ls.get(ls.size()-1);
		return pojo.getId();
	}

	@Override
	public int addProduct(ProductPOJO product) {
		String add = "insert into products values(?,?,?,?,?,?,?)";
		Object[] args = {product.getId(), product.getName(), product.getCategory(), product.getPrice(),product.getDescription(),product.getQuantity(),product.getImage() };
		int addS = jdbcTemplate.update(add, args);
		if (addS == 1)
		{
			System.out.println("Added Successfully!");
		}
		
		else
		{
			System.out.println("Unlucky :clown_face: ");
		}
		return 0;
	}
	
	@Override
	public ProductPOJO getProduct(int id) 
	{
		// TODO Auto-generated method stub
		String sql = "select * from products where id = ?";
		ProductPOJO product = jdbcTemplate.queryForObject(sql, new ProductRowMapper(), id);		
		return product;
	}

	@Override
	public int updateProduct(ProductPOJO product) 
	{
		// TODO Auto-generated method stub
		String sql = "update products set name = ?, category = ?,  price = ?, description = ?, quantity = ?, image=? where id = ?";
		Object[] args = {product.getName(), product.getCategory(), product.getPrice(), product.getDescription(), product.getQuantity(),product.getImage(), product.getId()};
		int recordsUpdated = jdbcTemplate.update(sql, args);
		return recordsUpdated;
	}

	@Override
	public void deleteProduct(int id) 
	{
		// TODO Auto-generated method stub
		String sql = "delete from products where id = ?";
		jdbcTemplate.update(sql, id);
	}

	
}
