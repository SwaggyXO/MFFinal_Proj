package proj.ncu.Ecomm_App.controller;


import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.method.annotation.RequestAttributeMethodArgumentResolver;
import org.springframework.web.servlet.view.RedirectView;

import com.mysql.cj.Session;

import proj.ncu.Ecomm_App.DAO.ProductDAOImpl;
import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.ProductPOJO;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
public class SellerController {
	
	@Autowired
	sellerDAOImpl sellerDAOImp;
	
	@Autowired
	ProductDAOImpl productDAOImpl;
	
	@ModelAttribute("sellerPOJO")
	public SellerPOJO getSellerPOJO()
	{
		return new SellerPOJO();
	}
	
	@RequestMapping(value= "/")
	public ModelAndView test(HttpServletResponse response, HttpServletRequest req, Model model) throws IOException{
		
		List<ProductPOJO> lis=productDAOImpl.getAllProducts();
		model.addAttribute("products",lis);
		return new ModelAndView("home");
	}
	@RequestMapping(value= "/h")
	public ModelAndView test2(HttpServletResponse response, HttpServletRequest req, Model model) throws IOException{
		
		List<ProductPOJO> lis=productDAOImpl.getAllProducts();
		model.addAttribute("products",lis);
		return new ModelAndView("home");
	}
	
	@RequestMapping(value= "/userType")
	public String getUserType()
	{
		return "userType";
	}
	
	@RequestMapping(value= "/sellerRegister")
	public String getSellerRegister()
	{
		return "sellerRegister";
	}
	
	@RequestMapping(value= "/validateSeller")
	public RedirectView validateseller(HttpServletRequest request,@RequestParam("pass")String pass,@RequestParam("username")String username)
	{
		System.out.println(username);
		System.out.println(pass);
		boolean is=sellerDAOImp.validate(username, pass);
		if(is) 
		{
			HttpSession session = request.getSession();
			session.removeAttribute("issellerlogin");
			session.removeAttribute("isbuyerlogin");
			session.setAttribute("issellerlogin", username);
			return new RedirectView("/Ecomm_App/sellerView2");
		}
		return new RedirectView("/Ecomm_App/sellerLogin");
	}
	
	@RequestMapping(value= "/sellerLogin")
	public String getSellerLogin()
	{
		return "sellerLogin";
	}
	
	@RequestMapping(value= "/sellerView2")
	public RedirectView getSellerConfirm2()
	{
		return new RedirectView("/Ecomm_App/sellerView");
	}
	
	@RequestMapping(value= "/sellerView1")
	public RedirectView getSellerConfirm(@ModelAttribute("sellerPOJO") SellerPOJO seller, Model model)
	{
		sellerDAOImp.addSeller(seller);
		
		return new RedirectView("sellerView");
	}
	
	@RequestMapping(value= "/logout")
	public RedirectView logout(HttpServletRequest request)
	{
		
		HttpSession session=request.getSession();
		session.invalidate();
		return new RedirectView("/Ecomm_App/");
	}
	
	
}
