package proj.ncu.Ecomm_App.SellerController;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import proj.ncu.Ecomm_App.DAO.sellerDAOImpl;
import proj.ncu.Ecomm_App.Entity.SellerPOJO;

@Controller
public class SellerController {
	
	@Autowired
	sellerDAOImpl sellerDAOImp;
	
	@ModelAttribute("sellerPOJO")
	public SellerPOJO getSellerPOJO()
	{
		return new SellerPOJO();
	}
	
	@RequestMapping(value= "/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("home");
	}
	
	@RequestMapping(value= "/userType")
	public String getUserType()
	{
		return "userType";
	}
	
	@RequestMapping(value= "/sellerLogin")
	public String getSellerLogin()
	{
		return "sellerLogin";
	}
	
	@RequestMapping(value= "/sellerConfirm")
	public String getSellerConfirm(@ModelAttribute("sellerPOJO") SellerPOJO seller, Model model)
	{
		sellerDAOImp.addSeller(seller);
		List<SellerPOJO> lsp =sellerDAOImp.getSeller("RishiDawggie");
		
		for (SellerPOJO spojo : lsp)
		{
			System.out.println(spojo.getAddress());
		}
		return "sellerConfirm";
	}
	
	
	
}
